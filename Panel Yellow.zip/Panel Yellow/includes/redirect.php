info: omg, we're welcome
stream default: 10
stream chat: 11
stream default: 10
stream chat: 11
stream default: 10
stream chat: 11
