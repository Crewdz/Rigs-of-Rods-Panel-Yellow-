This folder is used by the scripts to store files.
It's not recommended to use this folder for any other purposes.